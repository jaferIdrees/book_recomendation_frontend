const Login = () => {
    return (
        <p>Login Page</p>
    )
}

export default Login;