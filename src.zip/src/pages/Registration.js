const Registration = () =>{
    return (
        <p>Registration page</p>
    )
}

export default Registration;